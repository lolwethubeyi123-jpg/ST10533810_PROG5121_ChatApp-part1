/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
public class LoginTest {
    
}
// ----------------------------------------
//These variables store the user's details
//Once a user register, their data is stored here
 //----------------------------------------

String username;
String password;
String phoneNumber;


//-----------------------------------------------------------------------------------------------
//1. Check username 
//You are required to ensure;
// - Username contains an underscore "_"
// - Username is no more than 5 character long 
//------------------------------------------------------------------------------------------------
public boolean checkUIserName(String username)   {
    
    // username.contains("_") checks for the underscore 
    // username.length() <= 5 ensuree short username
    return username.contains("_") && username.length() <= 5;
    
}

//----------------------------------------------------------------------
        // 2. CHECK PASSWORD COMPLEXITY
        // Password requirements :
        // - At least 9 characters 
        // - At least two Capital letter
        // - At least two NUMBER 
        // - At least two SPECIAL characters 
        public boolean checkPasswordComplexicity(String password) {
            
             boolean hasCapital = false;
             boolean hasNumber =  false;
             boolean hasSpecial = false;
             
           for (int i = 0; < password.length(); i++);    
            
            char c= password.charAt (i)      
              if (Character.is Uppercase(c))  
               hasCapital = false; 
               
//Scanner always all the users to enter information 
        scanner input = new scanner(System.in ); 
        
        // Creating an object of the Login class so we can have the methods 
        Login login = new login (); 
        
        //--- Registration Section---
         System.out.println("---- User Registration ---");
         
         System.out.print("Enter a Username:");
         String userName = input.nextline();
         
         System.out.print("Enter a Username:");
         String password = input.nextLine(); 
         
         System.out.print("Enter your phone number:");
         String phone = input.nextLine();
         
         // Call the registerUser method and store the message its returns 
         String response = login.registerUser(userName,password,phone);
         
         //----Login Section---
         System.out.println("----User login");
         
         System.out.print("Enter username;");
         String loginUsername = input.nextLine();
         
         System.out.print("Enter your password:");
         String loginPasssword = input.nextLine();
         
         // Call loginUser to check if details match then store ones 
         boolean loggedIn = login.loginUser(loginUsername,loginPassword); 
         
         
         
    
    

