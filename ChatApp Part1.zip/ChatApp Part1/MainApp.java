/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

/**
 *
 * @author Student
 */
public class MainApp {
    public static void main(String[] args) {
        
        //Scanner always all the users to enter information 
        scanner input = new scanner(System.in );
        
        // Creating an object of the Login class so we can have the methods 
        Login login = new login ();
        
        //--- Registration Section---
         System.out.println("---- User Registration ---");
         
         System.out.print("Enter a Username:");
         String userName = input.nextline();
         
         System.out.print("Enter a Username:");
         String password = input.nextLine();
         
         System.out.print("Enter your phone number:");
         String phone = input.nextLine();
         
         // Call the registerUser method and store the message its returns 
         String response = login.registerUser(userName,password,phone);
         
         //----Login Section---
         System.out.println("----User login");
         
         System.out.print("Enter username;");
         String loginUsername = input.nextLine();
         
         System.out.print("Enter your password:");
         String loginPasssword = input.nextLine();
         
         // Call loginUser to check if details match then store ones 
         boolean loggedIn = login.loginUser(loginUsername,loginPassword);
         
         
         
    }
    
}
