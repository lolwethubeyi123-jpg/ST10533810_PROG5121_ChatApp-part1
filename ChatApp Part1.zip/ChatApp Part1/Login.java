/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

/**
 *
 * @author Student
 */
public class Login {
    
    //_------------------------------
    //These variables store the user's deatils
    // Once a user registers, their data is saved here 
    // ----------------------------
    String username;
    String password;
    String phoneNumber;
    
   
    //--------------------------------------------------------------------------
    // 1. CHECK USERNAME
    // You are required to ensure:
    // - Username contains an underscore
    // -----------------------------------------------------------------
    public boolean checkUserName(String username) {
        
        // username.contains("_") checks for the underscore 
        // username.length() <= 7 ensuring long username 
        public boolean checkUserName(String username)   
            return username.contains ("_") && username.length()<=5;
        }
        
        
        //----------------------------------------------------------------------
        // 2. CHECK PASSWORD COMPLEXITY
        // Password requirements :
        // - At least 9 characters 
        // - At least two Capital letter
        // - At least two NUMBER 
        // - At least two SPECIAL characters 
        public boolean checkPasswordComplexicity(String password) {
            
             boolean hasCapital = false;
             boolean hasNumber =  false;
             boolean hasSpecial = false;
             
           for (int i = 0; < password.length(); i++) {     
            
            char c= password.charAt (i)    
              if (Character.is Uppercase(c))   {       
               hasCapital = false;
              
           
       
        
        
 
        
            
        
        
  

            
        
            
        
        
        
        
        
        
     
        
        
       
   
       
        
        
    
           
    

